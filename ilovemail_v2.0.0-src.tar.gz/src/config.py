# General Configuration
__author__ = 'gdjohn4s'
__version__ = '2.0.0'
LOG: str = r'/home/homeerr/Documents/code/py/ilovemail/src/ilovemail.log'

# SMTP Server Auth
MAIL_FROM: str = "g.dandrea98@outlook.com"
MAIL_PWD: str = "Episodio01!"
MAIL_TO: str = "19giovanni.dandrea98@gmail.com", "dovahwolf@gmail.com"

# SMTP Options
SMTP_SERVER: str = "smtp-mail.outlook.com"
SMTP_PORT: int = 587
SSL_ENABLE: bool = True

# Mail Options
SUBJECT: str = "HELLO"
BODY: str = "My friend"