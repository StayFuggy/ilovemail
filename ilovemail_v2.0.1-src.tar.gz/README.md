# ILOVEMAIL
Welcome in this new fresh version of pyMail, now labeled **ilovemail!**

This script aims to notify users of a possible problem on their systems, it runs without an environment and my milestone is to make it simple as possible.
It's not completed because i wan't to add some features in near future, it works perfectly for simple purposes.

## Installation
As i said above, it's **simple** so you don't need to install some dependencies, just ensure you have at least **python 3.8.10** (Don't tested for below versions for now).
Download it from release tab and extract the file whatever you want.
Enjoy.

## Configuration
All parameters can be modified in **config_sample.py** file. Once finished, rename the file like this **config.py** and make sure it's positioned on the src root directory.

Execution example:
`python ilovemail.py`
or
`python3 ilovemail.py`

## Usage
That's your needs! Feel free to use like you want.
For example, if you have a monitoring system you can exec this script if CPU Usage of your server reach 99/100% idle for a few hours.

## Contribute!
I think it's obvius, but feel free to contribute if you want :)
